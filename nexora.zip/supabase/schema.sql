-- NEXORA portfolio: database, security rules and file storage
-- Run this whole file once in Supabase: SQL Editor > New query > paste > Run.
-- Safe to run again. It never deletes your records or files.

create extension if not exists pgcrypto;

-- ---------------------------------------------------------------
-- 1. Administrators and the is_admin() check used by every rule
-- ---------------------------------------------------------------
create table if not exists public.admins (
  user_id uuid primary key references auth.users(id) on delete cascade
);
alter table public.admins enable row level security;

create or replace function public.is_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (select 1 from public.admins where user_id = auth.uid());
$$;

drop policy if exists "admins read own row" on public.admins;
create policy "admins read own row" on public.admins
  for select to authenticated using (user_id = auth.uid());

-- ---------------------------------------------------------------
-- 2. Content tables
-- ---------------------------------------------------------------
create table if not exists public.site_profile (
  id int primary key default 1 check (id = 1),
  full_name text,
  headline text,
  bio text,
  degree text,
  college text,
  email text,
  linkedin text,
  github text,
  photo_path text,
  hidden_sections text[] not null default '{}',
  updated_at timestamptz not null default now()
);

create table if not exists public.skills (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  category text not null,
  stage text not null,
  description text,
  is_public boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.education (
  id uuid primary key default gen_random_uuid(),
  institution text not null,
  degree text not null,
  field text,
  start_year int,
  end_year int,
  grade text,
  location text,
  description text,
  is_public boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.certificates (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  issuer text not null,
  issue_date date,
  expiry_date date,
  credential_id text,
  verify_url text,
  description text,
  skills text[] not null default '{}',      -- approved skills only
  file_path text,
  file_name text,
  file_size bigint,
  published boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.projects (
  id uuid primary key default gen_random_uuid(),
  slug text not null unique,
  title text not null,
  summary text,
  problem text,
  solution text,                            -- description and features
  tech text[] not null default '{}',
  images text[] not null default '{}',
  video_url text,
  live_url text,
  repo_url text,
  project_status text,
  completion_date date,
  linkedin_caption text,
  linkedin_post_url text,
  published boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.experiences (
  id uuid primary key default gen_random_uuid(),
  organization text not null,
  role text not null,
  entry_type text not null default 'applied'
    check (entry_type in ('applied','shortlisted','selected','ongoing','completed')),
  start_date date,
  end_date date,
  description text,
  skills text[] not null default '{}',
  proof_url text,
  published boolean not null default false,
  created_at timestamptz not null default now()
);

-- Achievements and events share one table; "kind" tells them apart.
create table if not exists public.achievements (
  id uuid primary key default gen_random_uuid(),
  kind text not null default 'achievement' check (kind in ('achievement','event')),
  title text not null,
  organization text,
  item_date date,
  description text,
  link_url text,
  file_path text,
  file_name text,
  file_size bigint,
  published boolean not null default false,
  created_at timestamptz not null default now()
);

-- Added later (safe to run on an existing database):
alter table public.experiences add column if not exists category text not null default 'internship';
do $$ begin
  alter table public.experiences add constraint experiences_category_check check (category in ('internship','experience'));
exception when duplicate_object then null; end $$;
alter table public.achievements add column if not exists images text[] not null default '{}';
alter table public.achievements add column if not exists poster_path text;
alter table public.achievements add column if not exists participation text;
alter table public.projects add column if not exists thumbnail_path text;
alter table public.projects add column if not exists features text;
alter table public.site_profile add column if not exists grad_year int;
alter table public.site_profile add column if not exists location text;
alter table public.experiences add column if not exists offer_path text;
alter table public.experiences add column if not exists offer_name text;
alter table public.experiences add column if not exists completion_path text;
alter table public.experiences add column if not exists completion_name text;

create table if not exists public.resumes (
  id uuid primary key default gen_random_uuid(),
  file_path text not null,
  file_name text,
  file_size bigint,
  is_published boolean not null default false,
  created_at timestamptz not null default now()
);
-- Only one resume can be published at a time.
create unique index if not exists resumes_one_published on public.resumes (is_published) where is_published;

-- ---------------------------------------------------------------
-- 3. Row Level Security: visitors read published rows, admins do everything
-- ---------------------------------------------------------------
alter table public.site_profile enable row level security;
alter table public.skills       enable row level security;
alter table public.education    enable row level security;
alter table public.certificates enable row level security;
alter table public.projects     enable row level security;
alter table public.experiences  enable row level security;
alter table public.achievements enable row level security;
alter table public.resumes      enable row level security;

drop policy if exists "public read profile" on public.site_profile;
create policy "public read profile" on public.site_profile for select to anon, authenticated using (true);
drop policy if exists "admin write profile" on public.site_profile;
create policy "admin write profile" on public.site_profile for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

drop policy if exists "public read skills" on public.skills;
create policy "public read skills" on public.skills for select to anon, authenticated using (is_public);
drop policy if exists "admin all skills" on public.skills;
create policy "admin all skills" on public.skills for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

drop policy if exists "public read education" on public.education;
create policy "public read education" on public.education for select to anon, authenticated using (is_public);
drop policy if exists "admin all education" on public.education;
create policy "admin all education" on public.education for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

drop policy if exists "public read certificates" on public.certificates;
create policy "public read certificates" on public.certificates for select to anon, authenticated using (published);
drop policy if exists "admin all certificates" on public.certificates;
create policy "admin all certificates" on public.certificates for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

drop policy if exists "public read projects" on public.projects;
create policy "public read projects" on public.projects for select to anon, authenticated using (published);
drop policy if exists "admin all projects" on public.projects;
create policy "admin all projects" on public.projects for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

drop policy if exists "public read experiences" on public.experiences;
create policy "public read experiences" on public.experiences for select to anon, authenticated using (published);
drop policy if exists "admin all experiences" on public.experiences;
create policy "admin all experiences" on public.experiences for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

drop policy if exists "public read achievements" on public.achievements;
create policy "public read achievements" on public.achievements for select to anon, authenticated using (published);
drop policy if exists "admin all achievements" on public.achievements;
create policy "admin all achievements" on public.achievements for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

drop policy if exists "public read resumes" on public.resumes;
create policy "public read resumes" on public.resumes for select to anon, authenticated using (is_published);
drop policy if exists "admin all resumes" on public.resumes;
create policy "admin all resumes" on public.resumes for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

-- ---------------------------------------------------------------
-- 4. File storage: one private bucket, 10 MB per file, PDF and images only
-- ---------------------------------------------------------------
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values (
  'portfolio-files', 'portfolio-files', false, 10485760,
  array['application/pdf', 'image/png', 'image/jpeg', 'image/webp']
)
on conflict (id) do update
  set file_size_limit = excluded.file_size_limit,
      allowed_mime_types = excluded.allowed_mime_types,
      public = false;

drop policy if exists "admin manage files" on storage.objects;
create policy "admin manage files" on storage.objects for all to authenticated
  using (bucket_id = 'portfolio-files' and public.is_admin())
  with check (bucket_id = 'portfolio-files' and public.is_admin());

-- Visitors can only fetch a file when a PUBLISHED record points to it.
-- Drafts, unpublished resumes and orphaned files stay private.
drop policy if exists "public read published files" on storage.objects;
create policy "public read published files" on storage.objects for select to anon, authenticated
using (
  bucket_id = 'portfolio-files' and (
    exists (select 1 from public.certificates c where c.published and c.file_path = storage.objects.name)
    or exists (select 1 from public.projects p where p.published and (storage.objects.name = any (p.images) or p.thumbnail_path = storage.objects.name))
    or exists (select 1 from public.experiences x where x.published and (x.offer_path = storage.objects.name or x.completion_path = storage.objects.name))
    or exists (select 1 from public.achievements a where a.published and (a.file_path = storage.objects.name or a.poster_path = storage.objects.name or storage.objects.name = any (a.images)))
    or exists (select 1 from public.resumes r where r.is_published and r.file_path = storage.objects.name)
    or exists (select 1 from public.site_profile s where s.photo_path = storage.objects.name)
  )
);

-- ---------------------------------------------------------------
-- 5. Starting content: only what you have told me is true.
--    No projects, certificates, skills, education or achievements are pre-filled. You add them all in the admin page.
-- ---------------------------------------------------------------
insert into public.site_profile (id, full_name, linkedin, github)
values (1, 'Subaithal S.', 'https://www.linkedin.com/in/subaithal-s-812584426', 'https://github.com/Subaithals')
on conflict (id) do nothing;

-- ---------------------------------------------------------------
-- 6. MAKE YOURSELF THE ADMIN (run separately, after creating your user)
--    Supabase > Authentication > Users > Add user (your email + strong password).
--    Then run this with YOUR email:
--
--    insert into public.admins (user_id)
--    select id from auth.users where email = 'you@example.com';
-- ---------------------------------------------------------------
