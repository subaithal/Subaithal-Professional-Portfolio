/*
  NEXORA settings. This is the only file you edit to connect Supabase.

  1. Supabase dashboard > Project Settings > API
  2. Paste the Project URL and the "anon public" key below.

  The anon key is MEANT to be public (it is visible in every website that uses Supabase).
  Your data is protected by the Row Level Security rules in supabase/schema.sql, not by hiding this key.
  NEVER paste the "service_role" key here or anywhere in this project.

  While both values are empty, the public site still works and shows your four existing projects.
*/
window.NEXORA_CONFIG = {
  SUPABASE_URL: '',
  SUPABASE_ANON_KEY: ''
};
