(Beginners: read START-HERE.md first.)

# NEXORA Portfolio: setup guide (beginner steps)

Files (all go in the ROOT of your GitHub repo, no wrapper folder):

    index.html            Home (About, skills, education)
    projects.html certificates.html internships.html experience.html
    events.html achievements.html resume.html   (one page each)
    assets/app.js         shared site logic
    admin.html            private admin dashboard (open /admin)
    config.js             your Supabase URL + anon key (the only file you edit)
    vercel.json           makes /admin work
    assets/site.css       shared design
    supabase/schema.sql   database, security rules, storage

Architecture: still a plain static site (no build, Framework Preset "Other"). Supabase supplies login, database and file storage. A static page cannot hide secrets, so security comes from Supabase Row Level Security (RLS), not from hiding code. The anon key is public by design. NEVER use the service_role key anywhere.

## 0. Back up your old site first
In your GitHub repo, download/copy the current `index.html` as `index.old.html` (or make a branch `backup-before-nexora`). Do not skip this.

## 1. Create the Supabase project
1. supabase.com > sign in > New project. Pick a region near you and save the database password.
2. Wait until it is ready.

## 2. Database, rules, storage
1. SQL Editor > New query > paste all of `supabase/schema.sql` > Run. It is safe to run again; it never deletes your data.
2. It creates the tables, RLS on every table (public can read published items only), the private bucket `portfolio-files` (10 MB per file; PDF/PNG/JPG/WebP). Nothing is pre-filled: you add all projects and certificates yourself.

## 3. Create the admin account
1. Authentication > Users > Add user > your email + a strong password (tick auto-confirm).
2. Authentication > Sign In / Providers (or Settings) > turn OFF "Allow new users to sign up". This stops strangers creating accounts.
3. SQL Editor, run with YOUR email:
   `insert into public.admins (user_id) select id from auth.users where email = 'you@example.com';`
Only users listed in `admins` can write anything. A normal signed-in user still cannot.

## 4. Connect the site (env values)
Project Settings > API. Copy "Project URL" and the "anon public" key into `config.js`:

    SUPABASE_URL: 'https://xxxx.supabase.co',
    SUPABASE_ANON_KEY: 'eyJ...'

(Env var names, if you later move to a framework: `NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY`. Plain static hosting has no server env vars, so config.js is used.)

## 5. Update GitHub and redeploy (same URL)
1. In your existing repo, upload/replace these files in the root (keep the same repo).
2. Vercel redeploys automatically from the same repo and the same project, so the URL does not change. Keep Framework Preset "Other", no build command, output directory empty.
3. If you changed repos, do not create a new Vercel project; use Settings > Git on the existing one.

## 6. Use admin from your phone
Open `https://YOUR-SITE.vercel.app/admin`, sign in, and add to home screen. Upload certificates (PDF/image), set Published, and it appears on the site after a refresh. Draft items stay private.

## Notes on what is stored
- Certificates: no fixed limit in the app. Real limit is your Supabase plan.
- Skill suggestions from a certificate: you paste the certificate text; matching is keyword-based and you approve each skill. There is no real OCR (it needs a paid service). Nothing is saved without your approval.
- LinkedIn: posting is manual. The admin generates a caption; you copy and post, then paste the post URL.
- Data never expires automatically. Files are checked for type and size before upload; a failed upload leaves no half-saved record.

## Limits and backups (be honest with yourself)
- Storage is not unlimited or lifetime. The Supabase free plan has a small storage and database allowance (about 1 GB files / 500 MB database at the time of writing; verify at supabase.com/pricing) and free projects can be paused after about a week of no activity. Visit the site/admin regularly or upgrade.
- Free plan does not give you guaranteed backups you control. No backup exists until YOU do it:
  1. Monthly (and after big uploads): Admin > Settings > Download backup (JSON of all records).
  2. Keep your original certificate PDFs on your phone/Drive.
  3. Optional: Supabase > Database > Backups (paid plans) and `pg_dump`.
- Restore: re-run schema.sql on a new project, re-insert rows from the JSON in the SQL editor or Table Editor, re-upload files in admin. The JSON does not contain the files themselves.

## Tests: what was actually run
Run by me in a sandbox with a FAKE in-memory Supabase stand-in (not the real service):
- Public site loads, no JS errors, no horizontal scroll at 390px and 1280px; 4 project links and GitHub links present; anchors resolve.
- Published items show, drafts hidden; sections hide when empty.
- Admin: wrong password message; non-admin refused; admin sign-in; all 9 tabs render without errors or overflow; add certificate with validation and wrong-file-type rejection; upload request sent; unpublish; delete asks confirmation and cancel keeps it; sign-out; signed-out write blocked (stub).
Run by me on a real local PostgreSQL: schema ran twice cleanly; RLS checks: anonymous sees only published rows and cannot write, non-admin cannot write, admin can; one published resume only.

NOT run (cannot from my sandbox; you must run on your real deployment):
1. Real Supabase sign-in, real file upload progress, real signed URLs.
2. Persistence after refresh / sign-out / another device.
3. Real unauthorized write attempt against your project (try the anon key in the Supabase API docs "try it" or a second non-admin user).
4. Quota/error behaviour with real limits; broken-link behaviour with real files.
5. Live Vercel deploy, same URL, `/admin` route, phone use.
Checklist for you: add a test certificate with a PDF > publish > refresh > open in a private window (visible) > unpublish (disappears) > delete (confirm) > sign out > open `/admin` signed out (login only).

No independent review has been done, so no "10/10" claim is made.
