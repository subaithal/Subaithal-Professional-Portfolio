# START HERE (simple steps, Tanglish)

Idhu unga portfolio-oda pages:
Home (About) | Projects | Certificates | Experience | Internships | Events | Skills | Education | Achievements | Resume | Contact
Ovvondrum thani page. Admin page: `unga-site.vercel.app/admin`

## Mudhal: 1 nimisham ah purinjukonga
- Website = GitHub files + Vercel (ippo irukku, URL maaradhu).
- Neenga add panra projects, certificates, photos = **Supabase** la save aagum. Adhu oru free online database.
- Neenga Delete button press panni "Sure" nu sonna mattum tha delete aagum. Refresh, phone maathunaalum poga maattaadhu.

## Step 1: Supabase account (5 min)
1. supabase.com poi sign up pannunga. "New project" click. Name: portfolio. Oru password vechukonga (note pannunga). Region: Mumbai.
2. Ready aagura varaikum wait.

## Step 2: Database set pannunga
1. Left menu la "SQL Editor" > "New query".
2. `supabase/schema.sql` file open pannunga, full copy, SQL Editor la paste, "Run" click.
3. "Success" nu varanum.

## Step 3: Neenga mattum admin
1. Left menu "Authentication" > "Users" > "Add user" > "Create new user". Unga email + strong password. "Auto confirm user" tick.
2. Authentication > Sign In / Providers (illana Settings) > "Allow new users to sign up" **OFF**.
3. SQL Editor la idhu run pannunga (unga email maathunga):

       insert into public.admins (user_id) select id from auth.users where email = 'UNGA-EMAIL@gmail.com';

## Step 4: Website-ku Supabase connect
1. Supabase > Project Settings > API.
2. "Project URL" and "anon public" key copy.
3. `config.js` open panni, rendu quotes kulla paste:

       SUPABASE_URL: 'https://xxxx.supabase.co',
       SUPABASE_ANON_KEY: 'eyJ...'

   "service_role" key ENGAYUM paste pannadheenga.

## Step 5: GitHub la upload
1. Unga repo la, ella files-um (zip extract panni) upload. `assets` folder-um serthu.
2. Pazhaya `index.html` mudhalla backup edukkunga (index.old.html nu).
3. Commit. Vercel thaaney redeploy pannum. URL same.

## Step 6: Admin la add panna aarambinga
`unga-site.vercel.app/admin` > login.
- **Projects** > Add project: title, summary, GitHub link, demo link, screenshots (neriya select pannalaam), details > "Show on public site" tick > Save.
- **Certificates** > Add: title, issuer, date, photo/PDF upload, description > publish.
- **Internships and experience** > Add: "Which page?" la Internship illa Experience select.
- **Achievements and events** > Add: Type = Event, photos neriya upload.
- **Profile** > ungal photo upload, short intro, about text, location. (College / year inga illa.)
- **Education** > ungal college name, degree, years, grade add pannunga. Home + Education page-la automatic-a varum. Neenga add pannara varaikum home-la empty-a irukkum.
- **Skills** > unga skills add pannunga (neenga solldra skills mattum).
- Events la poster, neriya photos, organizer, participation status, certificate upload irukku. Experience la offer letter, completion certificate upload irukku.
Draft la vechaa public ku theriyaadhu. "Show on public site" tick pannina mattum theriyum.

## Mukkiyam
- Free plan la storage limit irukku, "lifetime guarantee" illa. Maadha maadham Settings > Download backup press pannunga.
- Certificate PDFs-ah unga phone/Drive la vechukonga.
- Konja naal use pannaama irundhaa free project pause aagum. Dashboard la "Restore" press panna thirumba varum.
