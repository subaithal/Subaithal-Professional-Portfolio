/* NEXORA public site logic. Shared by every page. Reads published data from Supabase, falls back to built-in content. */
(function () {
  'use strict';

  /* ---------- built-in content, used until (or instead of) the database ---------- */
  var DEFAULT_PROFILE = {
    full_name: 'Subaithal S.',
    headline: '',
    bio: '',
    email: '',
    linkedin: 'https://www.linkedin.com/in/subaithal-s-812584426',
    github: 'https://github.com/Subaithals',
    photo_path: null,
    location: '',
    hidden_sections: []
  };
  var DEFAULT_SKILLS = [];
  var DEFAULT_PROJECTS = [];
  var ENTRY = {
    applied: ['Application submitted', 'mute'], shortlisted: ['Shortlisted', 'warn'], selected: ['Selected (confirmed)', 'pur'],
    ongoing: ['Ongoing', 'ok'], completed: ['Completed', 'ok']
  };
  var BUCKET = 'portfolio-files';
  var PAGE = document.body.getAttribute('data-page') || 'home';
  var PAGE_TITLE = document.body.getAttribute('data-title') || '';

  var S = {
    profile: DEFAULT_PROFILE, skills: DEFAULT_SKILLS, edu: [], projects: DEFAULT_PROJECTS,
    certs: [], exps: [], achs: [], events: [], resume: null, urls: {}, resumeView: '', resumeDl: ''
  };

  /* ---------- helpers ---------- */
  var NONE = document.createElement('div');
  function $(id) { return document.getElementById(id) || NONE; }
  function el(tag, attrs, kids) {
    var n = document.createElement(tag);
    if (attrs) Object.keys(attrs).forEach(function (k) {
      if (attrs[k] == null) return;
      if (k === 'text') n.textContent = attrs[k];
      else if (k === 'class') n.className = attrs[k];
      else n.setAttribute(k, attrs[k]);
    });
    (kids || []).forEach(function (c) { if (c) n.appendChild(c); });
    return n;
  }
  function clear(n) { while (n.firstChild) n.removeChild(n.firstChild); }
  function safeUrl(u) {
    if (!u) return '';
    try { var x = new URL(u, location.href); return (x.protocol === 'https:' || x.protocol === 'http:') ? x.href : ''; } catch (e) { return ''; }
  }
  function monthYear(d) {
    if (!d) return '';
    var t = new Date(d + (String(d).length === 10 ? 'T00:00:00' : ''));
    return isNaN(t.getTime()) ? '' : t.toLocaleDateString('en-IN', { month: 'short', year: 'numeric' });
  }
  function isImage(name) { return /\.(png|jpe?g|webp)$/i.test(name || ''); }
  function btn(href, label, cls) {
    var u = safeUrl(href); if (!u) return null;
    return el('a', { class: 'btn sm' + (cls ? ' ' + cls : ''), href: u, target: '_blank', rel: 'noopener noreferrer', text: label });
  }
  function empty(t, d) { return el('div', { class: 'empty' }, [el('b', { text: t }), el('span', { text: d })]); }
  function safe(fn) { try { fn(); } catch (e) { if (window.console) console.error(e); } }
  function hidden(id) { return (S.profile.hidden_sections || []).indexOf(id) !== -1; }

  /* ---------- renderers ---------- */
  function renderHero() {
    var p = S.profile;
    $('hName').textContent = p.full_name || DEFAULT_PROFILE.full_name;
    showIf('hHeadline', p.headline);
    showIf('hLocWrap', p.location, 'hLocation');
    var e0 = S.edu[0];
    showIf('hEduWrap', e0 && [e0.degree, e0.institution].filter(Boolean).join(', '), 'hEdu');
    showIf('hYearWrap', e0 && e0.end_year, 'hGrad');
    var li = safeUrl(p.linkedin) || DEFAULT_PROFILE.linkedin, gh = safeUrl(p.github) || DEFAULT_PROFILE.github;
    ['heroLi', 'ctaLi', 'ftLi', 'cLi'].forEach(function (i) { $(i).href = li; });
    ['heroGh', 'ctaGh', 'ftGh', 'cGh'].forEach(function (i) { $(i).href = gh; });
    var hr = $('heroResume');
    if (S.resumeDl) { hr.textContent = 'Download Resume'; hr.href = S.resumeDl; hr.removeAttribute('target'); }
    else { hr.textContent = 'Resume'; hr.href = 'resume.html'; }
    var frame = $('frame'), path = p.photo_path, src = path && S.urls[path];
    if (src) {
      var img = new Image(); img.alt = 'Portrait of ' + (p.full_name || DEFAULT_PROFILE.full_name); img.decoding = 'async';
      img.onload = function () { clear(frame); frame.appendChild(img); };
      img.src = src;
    }
    var who = p.full_name || DEFAULT_PROFILE.full_name;
    document.title = (PAGE_TITLE ? PAGE_TITLE + ' | ' : '') + who + ' | AI and Data Science Portfolio';
  }

  function showIf(wrapId, val, textId) {
    var w = $(wrapId); if (!w) return;
    if (val) { if (textId) $(textId).textContent = val; else w.textContent = val; w.classList.remove('hide'); } else w.classList.add('hide');
  }

  function eduCard(e) {
    var yrs = (e.start_year ? e.start_year + ' - ' : '') + (e.end_year || '');
    var kids = [el('span', { class: 'label', text: yrs || 'Education' }), el('h3', { text: e.degree + (e.field ? ' in ' + e.field : '') }), el('p', { class: 'sum', text: e.institution })];
    var meta = [e.location, e.grade ? 'Grade: ' + e.grade : ''].filter(Boolean).join(' · ');
    if (meta) kids.push(el('p', { class: 'sum', text: meta }));
    if (e.description) kids.push(el('p', { class: 'sum', text: e.description }));
    return el('div', { class: 'card edu-card' }, kids);
  }
  function renderEdu() {
    var list = S.edu || [];
    var g = $('eduList'); clear(g);
    list.forEach(function (e) { g.appendChild(eduCard(e)); });
    var sec = $('eduSec'); if (sec) { if (list.length && !hidden('education')) sec.classList.remove('hide'); else sec.classList.add('hide'); }
    var pg = $('eduPage'); clear(pg);
    if (!list.length) pg.appendChild(empty('Education details coming soon', 'They appear here after they are added in the admin page.'));
    else list.forEach(function (e) { pg.appendChild(eduCard(e)); });
  }

  function renderAbout() {
    var p = S.profile;
    $('aboutText').textContent = p.bio || '';
    $('aboutSec').classList.toggle('hide', !p.bio);
    $('cLoc').textContent = p.location || '';
    showIf('cLocWrap', p.location);
    renderEdu();
    var mail = $('mailLine');
    if (p.email) { $('mailText').textContent = p.email; mail.classList.remove('hide'); } else mail.classList.add('hide');
    var ce = $('cEmailBox');
    if (p.email) { $('cEmail').textContent = p.email; ce.classList.remove('hide'); var mb = $('cMailBtn'); mb.href = 'mailto:' + p.email; } else ce.classList.add('hide');
  }

  function renderSkills() {
    var g = $('skillsGrid'); clear(g);
    if (!S.skills.length) { g.appendChild(empty('No skills added yet', 'Skills appear here after they are added in the admin page.')); return; }
    var cats = [];
    S.skills.forEach(function (s) { if (cats.indexOf(s.category) === -1) cats.push(s.category); });
    cats.forEach(function (c) {
      var chips = el('div', { class: 'chips' });
      S.skills.filter(function (s) { return s.category === c; }).forEach(function (s) {
        var ch = el('span', { class: 'chip', text: s.name + (s.stage ? ' · ' + s.stage : '') });
        if (s.description) ch.title = s.description;
        chips.appendChild(ch);
      });
      g.appendChild(el('div', { class: 'card' }, [el('span', { class: 'label', text: c }), chips]));
    });
  }

  function renderProjects() {
    var g = $('projectsGrid'); clear(g);
    if (!S.projects.length) { g.appendChild(empty('Projects coming soon', 'Projects will appear here after they are added in the admin page.')); return; }
    S.projects.forEach(function (p) {
      var cover = (p.thumbnail_path && S.urls[p.thumbnail_path]) || (p.images && p.images[0] && S.urls[p.images[0]]);
      var thumb = el('div', { class: 'thumb' });
      if (cover) thumb.appendChild(el('img', { src: cover, alt: p.title + ' screenshot', loading: 'lazy' }));
      else thumb.appendChild(el('span', { class: 'ph', 'aria-hidden': 'true', text: p.title.charAt(0) }));
      var kids = [thumb];
      var head = el('div', { class: 'head-row' }, [el('h3', { text: p.title })]);
      if (p.project_status) head.appendChild(el('span', { class: 'pill pur', text: p.project_status }));
      kids.push(head);
      kids.push(el('p', { class: 'sum', text: p.summary || (p.repo_url ? 'Live demo and source code are available.' : 'A live demo is available.') }));
      if (p.tech && p.tech.length) {
        var chips = el('div', { class: 'chips' });
        p.tech.forEach(function (t) { chips.appendChild(el('span', { class: 'chip', text: t })); });
        kids.push(chips);
      }
      var det = el('button', { class: 'btn sm', type: 'button', text: 'Details' });
      det.addEventListener('click', function () { openProject(p, det); });
      kids.push(el('div', { class: 'row' }, [det, btn(p.live_url, 'Live demo', 'primary'), btn(p.repo_url, 'GitHub')]));
      g.appendChild(el('article', { class: 'card lift' }, kids));
    });
  }

  function renderCerts() {
    var g = $('certGrid'); clear(g);
    if (!S.certs.length) { g.appendChild(empty('Certificates coming soon', 'Each certificate appears here with its photo and details after it is added in the admin page.')); return; }
    var today = new Date().toISOString().slice(0, 10);
    S.certs.forEach(function (c) {
      var url = c.file_path && S.urls[c.file_path];
      var thumb = el('div', { class: 'thumb' });
      if (url && isImage(c.file_name || c.file_path)) {
        thumb.appendChild(el('img', { src: url, alt: 'Preview of ' + c.title, loading: 'lazy' }));
        var z = el('button', { type: 'button', 'aria-label': 'Enlarge ' + c.title });
        z.addEventListener('click', function () { openImage(url, c.title, z); });
        thumb.appendChild(z);
      } else thumb.appendChild(el('span', { class: 'ph', 'aria-hidden': 'true', text: url ? 'PDF' : 'Certificate' }));
      var head = el('div', { class: 'head-row' }, [el('h3', { text: c.title })]);
      if (c.expiry_date) head.appendChild(el('span', { class: 'pill ' + (c.expiry_date < today ? 'crit' : 'mute'), text: c.expiry_date < today ? 'Expired' : 'Expires ' + monthYear(c.expiry_date) }));
      var meta = el('div', { class: 'meta-line' });
      meta.appendChild(el('span', { text: c.issuer }));
      if (c.issue_date) meta.appendChild(el('span', { text: 'Issued ' + monthYear(c.issue_date) }));
      if (c.credential_id) meta.appendChild(el('span', { text: 'ID ' + c.credential_id }));
      var kids = [thumb, head, meta];
      if (c.description) kids.push(el('p', { class: 'sum', text: c.description }));
      if (c.skills && c.skills.length) {
        var chips = el('div', { class: 'chips' });
        c.skills.forEach(function (s) { chips.appendChild(el('span', { class: 'chip', text: s })); });
        kids.push(chips);
      }
      var row = el('div', { class: 'row' });
      if (url) var _b1 = btn(url, isImage(c.file_name || c.file_path) ? 'Open file' : 'Open PDF'); if (_b1) row.appendChild(_b1);
      var v = btn(c.verify_url, 'Verify'); if (v) row.appendChild(v);
      if (row.childNodes.length) kids.push(row);
      g.appendChild(el('article', { class: 'card lift' }, kids));
    });
  }

  function renderExp() {
    [['internship', 'intList', 'No internships added yet', 'Internships appear here after they are added and published.'],
     ['experience', 'expList', 'No experience added yet', 'Work and project experience appears here after it is added and published.']].forEach(function (cfg) {
      var l = $(cfg[1]); clear(l);
      var rows = S.exps.filter(function (e) { return (e.category || 'internship') === cfg[0]; });
      if (!rows.length) { l.appendChild(empty(cfg[2], cfg[3])); return; }
      rows.forEach(function (e) {
        var t = ENTRY[e.entry_type] || ENTRY.applied;
        var when = '';
        if (e.start_date || e.end_date) when = monthYear(e.start_date) + (e.start_date ? ' to ' : '') + (e.end_date ? monthYear(e.end_date) : (e.start_date ? 'present' : ''));
        var kids = [el('div', { class: 'head-row' }, [el('h3', { text: e.role + ' · ' + e.organization }), el('span', { class: 'pill ' + t[1], text: t[0] })])];
        if (when) kids.push(el('span', { class: 'label', text: when }));
        if (e.description) kids.push(el('p', { class: 'sum', text: e.description }));
        if (e.skills && e.skills.length) { var c = el('div', { class: 'chips' }); e.skills.forEach(function (s) { c.appendChild(el('span', { class: 'chip quiet', text: s })); }); kids.push(c); }
        var rowE = el('div', { class: 'row' });
        var bo = e.offer_path && S.urls[e.offer_path] ? btn(S.urls[e.offer_path], 'Offer letter') : null; if (bo) rowE.appendChild(bo);
        var bc = e.completion_path && S.urls[e.completion_path] ? btn(S.urls[e.completion_path], 'Completion certificate') : null; if (bc) rowE.appendChild(bc);
        var b = btn(e.proof_url, 'Proof'); if (b) rowE.appendChild(b);
        if (rowE.childNodes.length) kids.push(rowE);
        l.appendChild(el('article', { class: 'card' }, kids));
      });
    });
  }

  function renderAch(list, gridId, emptyTitle, emptyText) {
    var g = $(gridId); clear(g);
    if (!list.length) { g.appendChild(empty(emptyTitle, emptyText)); return; }
    list.forEach(function (a) {
      var url = a.file_path && S.urls[a.file_path];
      var kids = [];
      var meta = [a.organization, monthYear(a.item_date)].filter(Boolean).join(' · ');
      if (meta) kids.push(el('span', { class: 'label', text: meta }));
      var poster = a.poster_path && S.urls[a.poster_path];
      if (poster) {
        var pt = el('div', { class: 'thumb poster' }, [el('img', { src: poster, alt: a.title + ' poster', loading: 'lazy' })]);
        var pz = el('button', { type: 'button', 'aria-label': 'Enlarge poster' });
        pz.addEventListener('click', function () { openImage(poster, a.title + ' poster', pz); });
        pt.appendChild(pz); kids.push(pt);
      }
      var shots = (a.images || []).map(function (i) { return S.urls[i]; }).filter(Boolean);
      if (shots.length) {
        var gal = el('div', { class: 'gallery mini' });
        shots.slice(0, 4).forEach(function (s, i) {
          var th = el('div', { class: 'thumb' }, [el('img', { src: s, alt: a.title + ' photo ' + (i + 1), loading: 'lazy' })]);
          var z = el('button', { type: 'button', 'aria-label': 'Enlarge photo ' + (i + 1) });
          z.addEventListener('click', function () { openImage(s, a.title, z); });
          th.appendChild(z); gal.appendChild(th);
        });
        kids.push(gal);
        if (shots.length > 4) kids.push(el('span', { class: 'label', text: '+ ' + (shots.length - 4) + ' more photos' }));
      } else if (!poster && url && isImage(a.file_name || a.file_path)) {
        var th2 = el('div', { class: 'thumb' }, [el('img', { src: url, alt: a.title, loading: 'lazy' })]);
        var z2 = el('button', { type: 'button', 'aria-label': 'Enlarge ' + a.title });
        z2.addEventListener('click', function () { openImage(url, a.title, z2); });
        th2.appendChild(z2); kids.push(th2);
      }
      var hd = el('div', { class: 'head-row' }, [el('h3', { text: a.title })]);
      if (a.participation) hd.appendChild(el('span', { class: 'pill pur', text: a.participation }));
      kids.push(hd);
      if (a.description) kids.push(el('p', { class: 'sum', text: a.description }));
      var row = el('div', { class: 'row' });
      if (url) var _b2 = btn(url, isImage(a.file_name || a.file_path) ? 'View certificate' : 'Open certificate'); if (_b2) row.appendChild(_b2);
      var l = btn(a.link_url, 'Link'); if (l) row.appendChild(l);
      if (row.childNodes.length) kids.push(row);
      g.appendChild(el('article', { class: 'card lift' }, kids));
    });
  }

  function renderResume() {
    var box = $('resumeBox'); clear(box);
    if (S.resumeView) {
      var dl = el('a', { class: 'btn primary', href: S.resumeDl || S.resumeView, text: 'Download resume' });
      var view = btn(S.resumeView, 'View in browser'); if (view) view.className = 'btn';
      box.appendChild(el('div', { class: 'card' }, [
        el('p', { class: 'sum', text: 'My current resume as a PDF' + (S.resume && S.resume.file_name ? ' (' + S.resume.file_name + ')' : '') + '.' }),
        el('div', { class: 'row' }, [dl, view])
      ]));
    } else box.appendChild(empty('Resume coming soon', 'The PDF will be available here once it is published. My LinkedIn profile has my details in the meantime.'));
  }

  var NAV = [['home', 'Home', 'index.html'], ['projects', 'Projects', 'projects.html'], ['certificates', 'Certificates', 'certificates.html'],
             ['experience', 'Experience', 'experience.html'], ['internships', 'Internships', 'internships.html'], ['events', 'Events', 'events.html'],
             ['skills', 'Skills', 'skills.html'], ['education', 'Education', 'education.html'], ['achievements', 'Achievements', 'achievements.html'],
             ['resume', 'Resume', 'resume.html'], ['contact', 'Contact', 'contact.html']];
  function pageShown(id) { return id === 'home' || !hidden(id); }
  function renderChrome() {
    var d = $('nav'), m = $('mnav'); clear(d); clear(m);
    NAV.forEach(function (n) {
      if (!pageShown(n[0])) return;
      [d, m].forEach(function (box) {
        var a = el('a', { href: n[2], text: n[1] });
        if (n[0] === PAGE) { a.className = 'on'; a.setAttribute('aria-current', 'page'); }
        box.appendChild(a);
      });
    });
    if (PAGE !== 'home' && hidden(PAGE)) { var pm = $('pageMain'); clear(pm); pm.appendChild(el('div', { class: 'wrap', style: 'padding-block:60px' }, [empty('This page is not available', 'The owner has hidden this section for now.')])); }
  }

  function renderAll() {
    safe(renderHero); safe(renderAbout); safe(renderSkills); safe(renderProjects); safe(renderCerts);
    safe(renderExp);
    safe(function () { renderAch(S.achs, 'achGrid', 'No achievements added yet', 'Awards and achievements appear here after they are added and published.'); });
    safe(function () { renderAch(S.events, 'eventGrid', 'No events added yet', 'Events I attended or took part in appear here with photos.'); });
    safe(renderResume); safe(renderChrome);
  }

  /* ---------- dialogs ---------- */
  var lastFocus = null;
  function closeLayer() {
    clear($('layer')); document.body.style.overflow = '';
    if (lastFocus && lastFocus.focus) lastFocus.focus();
  }
  function openLayer(content, opener, wide) {
    lastFocus = opener || null;
    var layer = $('layer'); clear(layer);
    var dlg = el('div', { class: 'dlg' + (wide ? ' wide' : ''), role: 'dialog', 'aria-modal': 'true' }, content);
    var scrim = el('div', { class: 'scrim' }, [dlg]);
    scrim.addEventListener('click', function (e) { if (e.target === scrim) closeLayer(); });
    layer.appendChild(scrim); document.body.style.overflow = 'hidden';
    return dlg;
  }
  function closeBtn() {
    var b = el('button', { class: 'btn sm ghost', type: 'button', 'aria-label': 'Close', text: 'Close' });
    b.addEventListener('click', closeLayer); return b;
  }
  function openImage(src, title, opener) {
    var cb = closeBtn();
    var dlg = openLayer([el('div', { class: 'fact', style: 'justify-content:space-between;align-items:center' }, [el('span', { class: 'label', text: title }), cb]),
      el('img', { src: src, alt: title })], opener);
    dlg.classList.add('imgdlg'); dlg.setAttribute('aria-label', title); cb.focus();
  }
  function openProject(p, opener) {
    var cb = closeBtn();
    var kids = [el('div', { class: 'head-row' }, [el('div', null, [el('span', { class: 'label', text: 'Project' + (p.project_status ? ' · ' + p.project_status : '') + (p.completion_date ? ' · ' + monthYear(p.completion_date) : '') }), el('h2', { id: 'pdT', text: p.title })]), cb])];
    var shots = (p.images || []).map(function (i) { return S.urls[i]; }).filter(Boolean);
    if (shots.length) {
      var gal = el('div', { class: 'gallery' });
      shots.forEach(function (s) {
        var th = el('div', { class: 'thumb' }, [el('img', { src: s, alt: p.title + ' screenshot', loading: 'lazy' })]);
        var z = el('button', { type: 'button', 'aria-label': 'Enlarge screenshot' });
        z.addEventListener('click', function () { openImage(s, p.title, z); });
        th.appendChild(z); gal.appendChild(th);
      });
      kids.push(gal);
    }
    if (p.summary) kids.push(el('p', { class: 'lede', style: 'font-size:17px', text: p.summary }));
    else kids.push(el('p', { class: 'sum', style: 'color:var(--fg2)', text: 'The full write-up for this project has not been added yet.' }));
    [['Problem', p.problem], ['Description', p.solution]].forEach(function (b) {
      if (b[1]) kids.push(el('div', { class: 'detail-block' }, [el('span', { class: 'label', text: b[0] }), el('p', { text: b[1] })]));
    });
    var feats = String(p.features || '').split('\n').map(function (x) { return x.trim(); }).filter(Boolean);
    if (feats.length) { var ul = el('ul', { class: 'feat' }); feats.forEach(function (f) { ul.appendChild(el('li', { text: f })); }); kids.push(el('div', { class: 'detail-block' }, [el('span', { class: 'label', text: 'Key features' }), ul])); }
    if (p.tech && p.tech.length) { var c = el('div', { class: 'chips' }); p.tech.forEach(function (t) { c.appendChild(el('span', { class: 'chip', text: t })); }); kids.push(el('div', { class: 'detail-block' }, [el('span', { class: 'label', text: 'Technologies' }), c])); }
    kids.push(el('div', { class: 'actions' }, [btn(p.live_url, 'Live demo', 'primary'), btn(p.repo_url, 'GitHub'), btn(p.video_url, 'Video'), btn(p.linkedin_post_url, 'LinkedIn post')]));
    var dlg = openLayer(kids, opener, true); dlg.setAttribute('aria-labelledby', 'pdT'); cb.focus();
  }
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && $('layer').firstChild) closeLayer(); });

  /* ---------- navigation behaviour ---------- */
  (function setupMenu() {
    var burger = $('burger'), mnav = $('mnav');
    function close() { mnav.classList.remove('open'); burger.setAttribute('aria-expanded', 'false'); burger.setAttribute('aria-label', 'Open menu'); }
    burger.addEventListener('click', function () {
      var o = mnav.classList.toggle('open'); burger.setAttribute('aria-expanded', o ? 'true' : 'false'); burger.setAttribute('aria-label', o ? 'Close menu' : 'Open menu');
    });
    mnav.addEventListener('click', function (e) { if (e.target && e.target.tagName === 'A') close(); });
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape') close(); });
  })();

  /* ---------- load saved data from Supabase ---------- */
  function load() {
    var cfg = window.NEXORA_CONFIG || {};
    if (!cfg.SUPABASE_URL || !cfg.SUPABASE_ANON_KEY || !window.supabase || !window.supabase.createClient) return;
    var sb;
    try { sb = window.supabase.createClient(cfg.SUPABASE_URL, cfg.SUPABASE_ANON_KEY, { auth: { persistSession: false, autoRefreshToken: false } }); }
    catch (e) { if (window.console) console.error(e); return; }

    function q(builder) {
      return builder.then(function (r) { return r && !r.error ? { ok: true, data: r.data || [] } : { ok: false, data: [] }; },
                          function () { return { ok: false, data: [] }; });
    }
    Promise.all([
      q(sb.from('site_profile').select('*').eq('id', 1)),
      q(sb.from('skills').select('name,category,stage,description').order('name', { ascending: true })),
      q(sb.from('certificates').select('*').order('issue_date', { ascending: false, nullsFirst: false })),
      q(sb.from('projects').select('*').order('created_at', { ascending: true })),
      q(sb.from('experiences').select('*').order('start_date', { ascending: false, nullsFirst: false })),
      q(sb.from('achievements').select('*').order('item_date', { ascending: false, nullsFirst: false })),
      q(sb.from('resumes').select('*').limit(1)),
      q(sb.from('education').select('*').order('end_year', { ascending: false, nullsFirst: false }))
    ]).then(function (r) {
      var profile = r[0], skills = r[1], certs = r[2], projects = r[3], exps = r[4], achs = r[5], resume = r[6], edu = r[7];
      if (!profile.ok && !projects.ok) return;          // database unreachable: keep the built-in content
      var merged = {}; Object.keys(DEFAULT_PROFILE).forEach(function (k) { merged[k] = DEFAULT_PROFILE[k]; });
      var row = profile.data[0] || {};
      Object.keys(row).forEach(function (k) { if (row[k] !== null && row[k] !== undefined && !(Array.isArray(row[k]) && k !== 'hidden_sections')) merged[k] = row[k]; });
      S.profile = merged;
      S.skills = skills.ok ? skills.data : DEFAULT_SKILLS;
      S.projects = projects.ok ? projects.data : DEFAULT_PROJECTS;
      S.certs = certs.data; S.exps = exps.data;
      S.achs = achs.data.filter(function (a) { return a.kind !== 'event'; });
      S.events = achs.data.filter(function (a) { return a.kind === 'event'; });
      S.resume = resume.data[0] || null;
      S.edu = edu.ok ? edu.data : [];

      var paths = [];
      function add(p) { if (p && paths.indexOf(p) === -1) paths.push(p); }
      add(S.profile.photo_path);
      S.certs.forEach(function (c) { add(c.file_path); });
      S.achs.concat(S.events).forEach(function (a) { add(a.file_path); add(a.poster_path); (a.images || []).forEach(add); });
      S.projects.forEach(function (p) { (p.images || []).forEach(add); add(p.thumbnail_path); });
      S.exps.forEach(function (e) { add(e.offer_path); add(e.completion_path); });
      var jobs = [];
      if (paths.length) jobs.push(sb.storage.from(BUCKET).createSignedUrls(paths, 3600).then(function (x) {
        (x.data || []).forEach(function (d) { if (d && d.path && d.signedUrl) S.urls[d.path] = d.signedUrl; });
      }, function () {}));
      if (S.resume && S.resume.file_path) {
        jobs.push(sb.storage.from(BUCKET).createSignedUrl(S.resume.file_path, 3600).then(function (x) { if (x.data) S.resumeView = x.data.signedUrl; }, function () {}));
        jobs.push(sb.storage.from(BUCKET).createSignedUrl(S.resume.file_path, 3600, { download: S.resume.file_name || 'resume.pdf' }).then(function (x) { if (x.data) S.resumeDl = x.data.signedUrl; }, function () {}));
      }
      return Promise.all(jobs).then(renderAll);
    }).catch(function (e) { if (window.console) console.error(e); });
  }

  /* ---------- start ---------- */
  safe(function () { $('yr').textContent = String(new Date().getFullYear()); });
  renderAll();
  load();
})();
